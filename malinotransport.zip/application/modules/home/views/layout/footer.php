  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; <a href="https://api.whatsapp.com/send?phone=085298730727&text=Halo%20Scrollup.studio">scrollup.strudio</a></p>
    </div>
    <!-- /.container -->
  </footer>
  <!-- Bootstrap core JavaScript -->
  <script src="<?= base_url('assets/home/'); ?>vendor/jquery/jquery.min.js"></script>
  <script src="<?= base_url('assets/home/'); ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="<?= base_url('assets/home/'); ?>vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom JavaScript for this theme -->
  <script src="<?= base_url('assets/home/'); ?>js/scrolling-nav.js"></script>

  </body>

  </html>